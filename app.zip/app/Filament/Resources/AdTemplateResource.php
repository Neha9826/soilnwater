<?php

namespace App\Filament\Resources;

use App\Filament\Resources\AdTemplateResource\Pages;
use App\Models\AdTemplate;
use Filament\Forms;
use Filament\Forms\Form;
use Filament\Resources\Resource;
use Filament\Forms\Components\Split;
use Filament\Forms\Components\Section;
use Filament\Forms\Components\TextInput;
use Filament\Forms\Components\FileUpload;
use Filament\Forms\Components\ColorPicker;
use Filament\Forms\Components\Repeater;
use Filament\Forms\Components\View;
use Filament\Forms\Components\Livewire;
use Filament\Tables;
use Filament\Tables\Table;

    class AdTemplateResource extends Resource
    {
        protected static ?string $model = AdTemplate::class;
        protected static ?string $navigationIcon = 'heroicon-o-presentation-chart-bar';

        public static function form(Form $form): Form
{
    return $form
        ->schema([
            Forms\Components\Split::make([
                Forms\Components\Section::make('Design Content')
                    ->schema([
                        Forms\Components\TextInput::make('name')
                            ->label('Template Internal Name')
                            ->required(),
                        
                        // Default Data fields specifically for the Beauty Clinic layout
                        Forms\Components\Group::make()->relationship('default_data')->schema([
                            Forms\Components\TextInput::make('company_name')->live()->default('Rimberio co'),
                            Forms\Components\TextInput::make('main_headline')->live()->default('BEAUTY CLINIC'),
                            Forms\Components\TextInput::make('discount_text')->live()->default('50% OFF'),
                            
                            Forms\Components\Repeater::make('services')
                                ->schema([
                                    Forms\Components\TextInput::make('item'),
                                ])->live()->default([['item' => 'Skin Care'], ['item' => 'Facial Treatment']]),
                            
                            Forms\Components\FileUpload::make('image_1')->image()->live(),
                            Forms\Components\FileUpload::make('image_2')->image()->live(),
                            Forms\Components\FileUpload::make('image_3')->image()->live(),
                        ]),
                    ])->columnSpan(2),

                Forms\Components\Section::make('Preview')
                    ->schema([
                        Forms\Components\View::make('livewire.admin.ad-preview')
                            ->viewData([
                                'get' => fn ($get) => $get,
                            ]),
                    ])->columnSpan(1),
            ])->columnSpanFull(),
        ]);
}

public static function table(Tables\Table $table): Tables\Table
{
    return $table
        ->columns([
            Tables\Columns\TextColumn::make('name'),
            Tables\Columns\TextColumn::make('layout_file'),
        ])
        ->actions([
            // Your "Clone/Use Template" logic goes here
            Tables\Actions\Action::make('use_template')
                ->label('Create My Copy')
                ->color('success')
                ->icon('heroicon-o-document-duplicate')
                ->action(function (AdTemplate $record) {
                    $userAd = \App\Models\UserAd::create([
                        'ad_template_id' => $record->id,
                        'user_id' => auth()->id(),
                        'title' => 'Copy of ' . $record->name,
                        'custom_data' => $record->default_data,
                    ]);
                    // Redirects to your new editor
                    return redirect()->to(\App\Filament\Resources\UserAdResource::getUrl('edit', ['record' => $userAd]));
                }),
            Tables\Actions\EditAction::make(),
        ]);
}

        public static function getPages(): array
        {
            return [
                'index' => Pages\ListAdTemplates::route('/'),
                'create' => Pages\CreateAdTemplate::route('/create'),
                'edit' => Pages\EditAdTemplate::route('/{record}/edit'),
            ];
        }
    }