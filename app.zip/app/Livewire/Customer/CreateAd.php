<?php

namespace App\Livewire\Customer;

use Livewire\Component;
use Livewire\WithFileUploads;
use App\Models\Ad;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Str; // Needed for string checking

class CreateAd extends Component
{
    use WithFileUploads;

    public $step = 1;
    
    // Selection Data
    public $tiers;
    public $templates = [];
    
    // User Choices
    public $selectedTierId;
    public $selectedTemplateId;
    public $selectedTemplate;
    
    // Form Inputs
    public $bg_color = '#ffffff';
    public $inputs = [];
    
    // --- REQUIRED VARIABLES FOR MULTI-IMAGE TEMPLATES ---
    public $image_upload;
    public $image_1_upload;
    public $image_2_upload;
    public $image_3_upload;
    public $logo_upload;

    public function mount()
    {
        $this->tiers = DB::table('ad_tiers')->get();
    }

    public function selectTier($id)
    {
        $this->selectedTierId = $id;
        $this->templates = DB::table('ad_templates')->where('ad_tier_id', $id)->get();
        $this->step = 2;
    }

    public function selectTemplate($id)
    {
        $this->selectedTemplateId = $id;
        $this->selectedTemplate = DB::table('ad_templates')->find($id);
        
        // 1. Reset all inputs and images to avoid ghosts
        $this->inputs = [];
        $this->reset(['image_upload', 'image_1_upload', 'image_2_upload', 'image_3_upload', 'logo_upload']);

        // 2. Initialize inputs based on required fields in DB
        if ($this->selectedTemplate) {
            $fields = json_decode($this->selectedTemplate->required_fields, true);
            if (is_array($fields)) {
                foreach($fields as $field) {
                    $this->inputs[$field] = '';
                }
            }
        }
        
        $this->step = 3;
    }

    public function save()
    {
        $contentData = $this->inputs;
        
        // 3. Save specific images if they were uploaded
        if ($this->image_upload) $contentData['image'] = $this->image_upload->store('ads/content', 'public');
        if ($this->image_1_upload) $contentData['image_1'] = $this->image_1_upload->store('ads/content', 'public');
        if ($this->image_2_upload) $contentData['image_2'] = $this->image_2_upload->store('ads/content', 'public');
        if ($this->image_3_upload) $contentData['image_3'] = $this->image_3_upload->store('ads/content', 'public');
        if ($this->logo_upload) $contentData['logo'] = $this->logo_upload->store('ads/content', 'public');

        Ad::create([
            'user_id' => Auth::id(),
            'ad_tier_id' => $this->selectedTierId,
            'ad_template_id' => $this->selectedTemplateId,
            'title' => $this->inputs['headline'] ?? 'Untitled Ad',
            'bg_color' => $this->bg_color,
            'content_data' => $contentData,
            'status' => 'pending_payment',
            'final_image_path' => 'generated_on_view', 
        ]);

        session()->flash('message', 'Ad drafted! Please proceed to payment.');
        return redirect()->route('customer.listings');
    }

    public function goBack()
    {
        if ($this->step > 1) $this->step--;
    }

    public function render()
    {
        return view('livewire.customer.create-ad')->layout('layouts.app');
    }
}