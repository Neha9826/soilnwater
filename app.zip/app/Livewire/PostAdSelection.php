<?php

namespace App\Livewire;

use Livewire\Component;

class PostAdSelection extends Component
{
    public function render()
    {
        return view('livewire.post-ad-selection');
    }
}
