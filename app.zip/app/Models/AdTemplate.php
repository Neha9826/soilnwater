<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class AdTemplate extends Model
{
    protected $fillable = ['name', 'layout_file', 'default_data'];

    protected $casts = [
        'default_data' => 'array',
    ];
}
