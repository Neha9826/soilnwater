@props(['data', 'bgColor'])

<div class="w-full h-full relative overflow-hidden bg-[#fffdf9]" style="background-color: {{ $bgColor }}">
    <div class="absolute top-0 left-0 w-full h-[35%] bg-[#8D6E63] z-0 opacity-20" style="border-bottom-left-radius: 50% 20%; border-bottom-right-radius: 50% 80%;"></div>
    <div class="absolute bottom-0 right-0 w-full h-[45%] bg-[#5D4037] z-0" style="border-top-left-radius: 100% 50%;"></div>

    <div class="absolute top-16 left-8 z-10 w-[45%]">
        <p class="font-handwriting text-[#8D6E63] text-2xl mb-0 transform -rotate-2">{{ $data['subheadline'] ?? 'Special Today' }}</p>
        <h1 class="text-6xl font-black text-[#3E2723] leading-[0.8] mb-6 tracking-tighter">{{ $data['title_1'] ?? 'BEAUTY' }}<br><span class="text-[#5D4037]">{{ $data['title_2'] ?? 'CLINIC' }}</span></h1>
        
        <div class="bg-white/95 p-4 rounded-xl shadow-lg border border-[#D7CCC8] max-w-[200px]">
            <span class="bg-[#3E2723] text-white px-3 py-1 text-[10px] font-bold uppercase rounded-sm mb-2 inline-block">More Info</span>
            <p class="text-sm font-bold text-[#3E2723]">{{ $data['phone'] ?? '123-456-7890' }}</p>
            <p class="text-[10px] text-[#5D4037]">{{ $data['website'] ?? 'www.website.com' }}</p>
        </div>
    </div>

    <div class="absolute right-0 top-0 w-[55%] h-full z-10 pointer-events-none">
        <div class="absolute top-8 right-8 w-44 h-44 rounded-full border-[8px] border-white shadow-2xl overflow-hidden bg-gray-200 z-10">
            @if(isset($data['image_1']) && is_object($data['image_1']) && method_exists($data['image_1'], 'temporaryUrl'))
                <img src="{{ $data['image_1']->temporaryUrl() }}" class="w-full h-full object-cover">
            @elseif(isset($data['image_1']) && is_string($data['image_1']) && !empty($data['image_1']))
                <img src="{{ asset('storage/'.$data['image_1']) }}" class="w-full h-full object-cover">
            @endif
        </div>
        <div class="absolute top-[40%] left-[-30px] w-32 h-32 rounded-full border-[4px] border-dashed border-white bg-[#6D4C41] flex flex-col items-center justify-center text-white shadow-2xl z-30">
            <span class="text-3xl font-black leading-none">50%</span><span class="text-[10px] font-bold uppercase tracking-widest">OFF</span>
        </div>
        <div class="absolute bottom-12 right-12 w-40 h-40 rounded-full border-[8px] border-white shadow-2xl overflow-hidden bg-gray-200 z-20">
            @if(isset($data['image_2']) && is_object($data['image_2']) && method_exists($data['image_2'], 'temporaryUrl'))
                <img src="{{ $data['image_2']->temporaryUrl() }}" class="w-full h-full object-cover">
            @elseif(isset($data['image_2']) && is_string($data['image_2']) && !empty($data['image_2']))
                <img src="{{ asset('storage/'.$data['image_2']) }}" class="w-full h-full object-cover">
            @endif
        </div>
        <div class="absolute bottom-4 left-0 w-20 h-20 rounded-full border-[4px] border-white shadow-xl overflow-hidden bg-gray-100 z-10">
             @if(isset($data['image_3']) && is_object($data['image_3']) && method_exists($data['image_3'], 'temporaryUrl'))
                <img src="{{ $data['image_3']->temporaryUrl() }}" class="w-full h-full object-cover">
            @elseif(isset($data['image_3']) && is_string($data['image_3']) && !empty($data['image_3']))
                <img src="{{ asset('storage/'.$data['image_3']) }}" class="w-full h-full object-cover">
            @endif
        </div>
    </div>
</div>