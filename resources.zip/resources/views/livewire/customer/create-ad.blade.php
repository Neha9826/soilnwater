<div class="min-h-screen bg-gray-50 py-12 px-4">
    <div class="max-w-7xl mx-auto">
        
        {{-- PROGRESS HEADER --}}
        <div class="flex justify-between items-center mb-8 px-4 border-b border-gray-200 pb-4">
            <div class="flex gap-6 text-sm">
                <span class="{{ $step >= 1 ? 'text-blue-600 font-bold' : 'text-gray-400' }}">1. Select Size</span>
                <i class="fas fa-chevron-right text-gray-300"></i>
                <span class="{{ $step >= 2 ? 'text-blue-600 font-bold' : 'text-gray-400' }}">2. Pick Template</span>
                <i class="fas fa-chevron-right text-gray-300"></i>
                <span class="{{ $step >= 3 ? 'text-blue-600 font-bold' : 'text-gray-400' }}">3. Customize</span>
            </div>
            @if($step > 1)
                <button wire:click="goBack" class="text-gray-500 hover:text-gray-800 font-bold text-sm flex items-center gap-1">
                    <i class="fas fa-arrow-left"></i> Back
                </button>
            @endif
        </div>

        {{-- STEP 1: CHOOSE SIZE --}}
        @if($step === 1)
            <div class="text-center mb-10">
                <h1 class="text-3xl font-extrabold text-gray-900">Choose Ad Size & Priority</h1>
            </div>
            <div class="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
                @foreach($tiers as $tier)
                    <div wire:click="selectTier({{ $tier->id }})" 
                         class="bg-white rounded-2xl shadow-sm hover:shadow-xl transition cursor-pointer border-2 border-transparent hover:border-blue-500 p-6 flex flex-col items-center text-center relative overflow-hidden group">
                        @if($tier->is_premium) <div class="absolute top-0 right-0 bg-yellow-400 text-yellow-900 text-xs font-bold px-3 py-1 rounded-bl-lg shadow-sm">PREMIUM</div> @endif
                        <div class="bg-gray-100 border border-gray-300 mb-4 flex items-center justify-center text-gray-400 font-bold text-xs group-hover:bg-blue-50 group-hover:border-blue-200 group-hover:text-blue-500 transition rounded"
                             style="width: {{ $tier->width_units * 40 }}px; height: {{ $tier->height_units * 40 }}px;">
                            {{ $tier->width_units }}x{{ $tier->height_units }}
                        </div>
                        <h3 class="text-lg font-bold text-gray-900">{{ $tier->name }}</h3>
                        <p class="text-2xl font-extrabold text-blue-600 mt-2">₹{{ number_format($tier->price) }}</p>
                    </div>
                @endforeach
            </div>
        @endif

        {{-- STEP 2: CHOOSE TEMPLATE --}}
        @if($step === 2)
            <div class="text-center mb-10">
                <h1 class="text-3xl font-extrabold text-gray-900">Pick a Design</h1>
            </div>
            <div class="grid grid-cols-1 md:grid-cols-3 gap-6">
                @foreach($templates as $temp)
                    <div wire:click="selectTemplate({{ $temp->id }})" 
                         class="bg-white rounded-xl shadow-sm hover:shadow-xl transition cursor-pointer border-2 border-transparent hover:border-blue-500 overflow-hidden group flex flex-col h-full">
                        <div class="aspect-square bg-gray-100 relative flex items-center justify-center overflow-hidden">
                            @if($temp->thumbnail && file_exists(public_path($temp->thumbnail)))
                                <img src="{{ asset($temp->thumbnail) }}" class="w-full h-full object-cover opacity-90 group-hover:opacity-100 transition duration-500 group-hover:scale-105">
                            @else
                                <div class="text-center text-gray-400"><i class="fas fa-image text-4xl mb-2 opacity-50"></i><p class="text-[10px] font-bold uppercase tracking-wider">No Preview</p></div>
                            @endif
                        </div>
                        <div class="p-4 border-t border-gray-100 flex-grow flex items-center justify-between">
                            <h3 class="font-bold text-gray-900">{{ $temp->name }}</h3>
                            <i class="fas fa-arrow-right text-gray-300 group-hover:text-blue-500 transition"></i>
                        </div>
                    </div>
                @endforeach
            </div>
        @endif

        {{-- STEP 3: CUSTOMIZE & PREVIEW --}}
        @if($step === 3)
            <div class="flex flex-col lg:flex-row gap-8 items-start w-full">
                
                {{-- LEFT: FORM INPUTS --}}
                <div class="w-full lg:w-1/3 bg-white p-6 rounded-xl shadow-sm border border-gray-200 sticky top-6 max-h-[90vh] overflow-y-auto">
                    <h2 class="text-lg font-bold text-gray-900 mb-4 pb-2 border-b border-gray-100 flex items-center gap-2">
                        <i class="fas fa-pen-fancy text-blue-500"></i> Edit Content
                    </h2>
                    
                    <div class="space-y-5">
                        {{-- 1. DYNAMIC FIELDS (Skip Contact fields to show them manually below) --}}
                        @foreach($inputs as $key => $value)
                            @if(in_array($key, ['phone', 'address', 'website'])) @continue @endif

                            <div>
                                <label class="block text-xs font-bold text-gray-600 uppercase mb-1.5">{{ str_replace('_', ' ', $key) }}</label>
                                
                                {{-- Image Inputs --}}
                                @if(Str::contains($key, 'image') || Str::contains($key, 'logo'))
                                    @php
                                        $modelName = match($key) {
                                            'image_1' => 'image_1_upload',
                                            'image_2' => 'image_2_upload',
                                            'image_3' => 'image_3_upload',
                                            'logo'    => 'logo_upload',
                                            default   => 'image_upload'
                                        };
                                    @endphp
                                    <div class="relative group">
                                        <label class="flex flex-col items-center justify-center w-full h-24 border-2 border-dashed border-gray-300 rounded-lg cursor-pointer bg-gray-50 hover:bg-gray-100 relative overflow-hidden">
                                            @if($this->{$modelName})
                                                <img src="{{ $this->{$modelName}->temporaryUrl() }}" class="absolute inset-0 w-full h-full object-cover z-20">
                                            @else
                                                <div class="text-center z-10"><i class="fas fa-cloud-upload-alt text-gray-400"></i><p class="text-[9px] text-gray-500 font-bold">Click to Upload</p></div>
                                            @endif
                                            <input wire:model.live="{{ $modelName }}" type="file" class="hidden" accept="image/*">
                                        </label>
                                    </div>
                                {{-- Date/Text Inputs --}}
                                @elseif(Str::contains($key, 'date'))
                                    <input wire:model.live="inputs.{{ $key }}" type="date" class="w-full border-gray-300 rounded-lg text-sm">
                                @elseif($key == 'description')
                                    <textarea wire:model.live="inputs.{{ $key }}" rows="3" class="w-full border-gray-300 rounded-lg text-sm p-2"></textarea>
                                @else
                                    <input wire:model.live="inputs.{{ $key }}" type="text" class="w-full border-gray-300 rounded-lg text-sm p-2">
                                @endif
                            </div>
                        @endforeach

                        {{-- 2. MANUAL CONTACT INFO (Always visible/editable) --}}
                        <div class="pt-4 border-t border-gray-100">
                            <h3 class="text-xs font-bold text-gray-400 uppercase tracking-widest mb-3">Contact Details</h3>
                            <div class="space-y-3">
                                <div>
                                    <label class="block text-[10px] font-bold text-gray-500 uppercase">Phone Number</label>
                                    <input wire:model.live="inputs.phone" type="text" class="w-full border-gray-300 rounded-lg text-sm p-2" placeholder="+123 456 7890">
                                </div>
                                <div>
                                    <label class="block text-[10px] font-bold text-gray-500 uppercase">Address / Location</label>
                                    <input wire:model.live="inputs.address" type="text" class="w-full border-gray-300 rounded-lg text-sm p-2" placeholder="Street, City">
                                </div>
                                <div>
                                    <label class="block text-[10px] font-bold text-gray-500 uppercase">Website / Link</label>
                                    <input wire:model.live="inputs.website" type="text" class="w-full border-gray-300 rounded-lg text-sm p-2" placeholder="www.example.com">
                                </div>
                            </div>
                        </div>

                        {{-- 3. COLOR PICKER --}}
                        <div class="pt-4 border-t border-gray-100">
                            <label class="block text-xs font-bold text-gray-600 uppercase mb-2">Background Color</label>
                            <div class="flex items-center gap-3">
                                <input type="color" wire:model.live="bg_color" class="h-10 w-full cursor-pointer rounded-lg border border-gray-300 p-1">
                                <span class="text-xs font-mono text-gray-500 bg-gray-100 px-2 py-1 rounded">{{ $bg_color }}</span>
                            </div>
                        </div>
                    </div>

                    <div class="mt-6">
                        <button wire:click="save" class="w-full bg-green-600 text-white font-bold py-3.5 rounded-xl hover:bg-green-700 shadow-lg">Pay & Publish</button>
                    </div>
                </div>

                {{-- RIGHT: PREVIEW --}}
                <div class="w-full lg:w-2/3 sticky top-6">
                    <div class="bg-gray-800 rounded-t-xl py-3 px-4 flex justify-between items-center shadow-md">
                        <h3 class="text-xs font-bold text-gray-300 uppercase tracking-widest"><i class="fas fa-eye mr-2"></i>Live Preview</h3>
                    </div>
                    <div class="bg-gray-200 rounded-b-xl p-8 flex items-center justify-center min-h-[600px] border border-gray-300 shadow-inner">
                        <div class="relative bg-white shadow-2xl overflow-hidden transition-all duration-300 ring-1 ring-gray-900/5" style="width: 500px; height: 500px;">
                            @if($selectedTemplate)
                                {{-- 
                                    CRITICAL FIX HERE: Using array_merge()
                                    This forces the Uploaded Image Object to OVERWRITE the empty text string from the DB inputs.
                                --}}
                                <x-dynamic-component 
                                    :component="$selectedTemplate->view_component"
                                    :data="array_merge($inputs, [
                                        'image'   => $image_upload ?: ($inputs['image'] ?? null), 
                                        'image_1' => $image_1_upload ?: ($inputs['image_1'] ?? null), 
                                        'image_2' => $image_2_upload ?: ($inputs['image_2'] ?? null),
                                        'image_3' => $image_3_upload ?: ($inputs['image_3'] ?? null),
                                        'logo'    => $logo_upload ?: ($inputs['logo'] ?? null)
                                    ])"
                                    :bg-color="$bg_color" 
                                />
                            @else
                                <div class="flex flex-col items-center justify-center h-full text-gray-400 gap-3">
                                    <i class="fas fa-spinner fa-spin text-3xl"></i>
                                    <span class="text-sm font-medium">Loading Template...</span>
                                </div>
                            @endif
                        </div>
                    </div>
                </div>
            </div>
        @endif
    </div>
</div>